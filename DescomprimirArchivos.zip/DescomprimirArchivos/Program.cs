﻿using System;
using System.IO;
using System.IO.Compression;

class Program
{
    static void Main(string[] args)
    {
        try
        {
            // Ruta del archivo ZIP
            string zipFilePath = @"C:\Users\JuanL\OneDrive - Cavipetrol\Documentos\HU_JUANLEGUIZAMON\GMF\ArchivosEjemplo\TEST.zip";

            // Ruta donde se descomprimirán los archivos
            string extractPath = @"C:\Users\JuanL\OneDrive - Cavipetrol\Documentos\HU_JUANLEGUIZAMON\GMF\ArchivosEjemplo\COMPRIMIDOS\";

            // Verificar si el archivo ZIP existe
            if (!File.Exists(zipFilePath))
            {
                Console.WriteLine("El archivo ZIP no existe: " + zipFilePath);
                return;
            }

            // Verificar si la carpeta de destino existe
            if (!Directory.Exists(extractPath))
            {
                Console.WriteLine("La carpeta de destino no existe: " + extractPath);
                return;
            }

            // Eliminar archivos existentes en la carpeta
            Console.WriteLine("Eliminando archivos existentes en la carpeta...");
            DirectoryInfo directory = new DirectoryInfo(extractPath);

            foreach (FileInfo file in directory.GetFiles())
            {
                file.Delete();
            }

            foreach (DirectoryInfo subDirectory in directory.GetDirectories())
            {
                subDirectory.Delete(true);
            }

            Console.WriteLine("Archivos eliminados.");

            // Descomprimir los archivos directamente en la carpeta de destino
            Console.WriteLine("Descomprimiendo el archivo ZIP...");
            using (ZipArchive archive = ZipFile.OpenRead(zipFilePath))
            {
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    string destinationPath = Path.Combine(extractPath, entry.FullName);

                    // Evitar la creación de carpetas
                    if (Path.GetFileName(destinationPath) != string.Empty)
                    {
                        // Extraer el archivo
                        entry.ExtractToFile(destinationPath, overwrite: true);

                        // Renombrar el archivo
                        string fileName = Path.GetFileNameWithoutExtension(destinationPath); // Nombre sin extensión
                        int lastDashIndex = fileName.LastIndexOf('-'); // Última posición del guion
                        string newFileName = lastDashIndex != -1
                            ? fileName.Substring(lastDashIndex + 1) // Extraer la parte después del último guion
                            : fileName;

                        string newFilePath = Path.Combine(extractPath, newFileName + Path.GetExtension(destinationPath));
                        File.Move(destinationPath, newFilePath); // Renombrar el archivo
                        Console.WriteLine($"Archivo renombrado a: {newFileName + Path.GetExtension(destinationPath)}");
                    }
                }
            }

            Console.WriteLine("Archivo descomprimido y renombrado exitosamente en: " + extractPath);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al descomprimir el archivo: " + ex.Message);
        }
    }
}
